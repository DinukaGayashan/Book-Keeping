Important
---------

Accounts folder & balance.txt, transaction.txt files are required to run the program.

Bank valt account number is considered as 000000, same as 0.
